module.exports = async (req, res) => {
  res.status(200).json({ sucesso: true, mensagem: 'Interesse registrado com sucesso.' });
};
