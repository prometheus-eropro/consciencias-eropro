module.exports = async (req, res) => {
    if (req.method !== 'POST') return res.status(405).end();

    const { nome, email, mensagem } = req.body;

    if (!nome || !email || !mensagem) {
        return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
    }

    console.log('Interesse registrado:', { nome, email, mensagem });

    return res.status(200).json({ sucesso: true, mensagem: 'Interesse registrado com sucesso.' });
};
