module.exports = async (req, res) => {
  res.status(200).json({ resposta: 'Chat em desenvolvimento.' });
  const urlLogs = 'https://https://script.google.com/macros/s/AKfycbz2Nz9MdsM-0g5CQWwIglNjyu4oq9Cx1Sc4-VSje4tamQNzxJP7hy61hr2YvugLXs0H/exec';

};
