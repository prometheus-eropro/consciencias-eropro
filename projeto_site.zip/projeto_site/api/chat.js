module.exports = async (req, res) => {
  res.status(200).json({ resposta: 'Chat em desenvolvimento.' });
};
