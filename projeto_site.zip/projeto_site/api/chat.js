const OpenAI = require('openai');

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

module.exports = async (req, res) => {
    if (req.method !== 'POST') return res.status(405).end();

    const { mensagens } = req.body;

    if (!mensagens || !Array.isArray(mensagens)) {
        return res.status(400).json({ error: 'Mensagens inválidas.' });
    }

    try {
        const completion = await openai.chat.completions.create({
            model: 'gpt-3.5-turbo',
            messages: mensagens
        });

        const resposta = completion.choices[0].message.content;

        return res.status(200).json({ resposta });
    } catch (error) {
        console.error('Erro no chat:', error);
        return res.status(500).json({ error: 'Erro ao processar a resposta.' });
    }
};
