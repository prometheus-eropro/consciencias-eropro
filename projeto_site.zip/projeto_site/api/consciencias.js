const axios = require('axios');

module.exports = async (req, res) => {
  try {
    const response = await axios.get('URL_DA_SUA_API_DO_GOOGLE_APPS_SCRIPT');

    const consciencias = response.data.conscias;

    res.status(200).json({ consciencias });
  } catch (error) {
    console.error('Erro ao acessar API:', error);
    res.status(500).json({ error: 'Erro no servidor.' });
  }
};
