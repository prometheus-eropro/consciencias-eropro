const axios = require('axios');

module.exports = async (req, res) => {
  try {
    const response = await axios.get('https://script.google.com/macros/s/AKfycbzxonxz2OZ-FudBx5_8IaONK3ggg19zQZ7kI5kthpnvcbs4ZpK-bdPSOyP6qMG02HjNAA/exec');

    const consciencias = response.data.conscias;

    res.status(200).json({ consciencias });
  } catch (error) {
    console.error('Erro ao acessar API:', error);
    res.status(500).json({ error: 'Erro no servidor.' });
  }
};
