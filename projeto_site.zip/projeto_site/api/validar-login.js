import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Método não permitido' });
  }

  const { emailOuCelular, senha } = req.body;

  if (!emailOuCelular || !senha) {
    return res.status(400).json({ message: 'Dados incompletos' });
  }

  // Caminho absoluto para o CSV
  const csvPath = path.join(process.cwd(), 'public', 'usuarios.csv');
  const csvData = fs.readFileSync(csvPath, 'utf8');

  // Separando as linhas
  const linhas = csvData.split('\n').filter(l => l.trim() !== '');
  const cabecalho = linhas[0].split(',');

  let acessoLiberado = false;

  for (let i = 1; i < linhas.length; i++) {
    const campos = linhas[i].split(',');
    const email = campos[0].trim();
    const senhaArmazenada = campos[1].trim();
    const ativo = campos[2].trim().toLowerCase();

    if ((email === emailOuCelular || email === `'${emailOuCelular}`) && senha === senhaArmazenada && ativo === 'sim') {
      acessoLiberado = true;
      break;
    }
  }

  if (acessoLiberado) {
    res.status(200).json({ acesso: true });
  } else {
    res.status(200).json({ acesso: false });
  }
}
