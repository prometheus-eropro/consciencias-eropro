import { useState } from 'react';

export default function AreaAssinante() {
  const [mensagem, setMensagem] = useState('');
  const [resposta, setResposta] = useState('');
  const [carregando, setCarregando] = useState(false);

  async function enviarMensagem() {
    if (!mensagem) return;

    setCarregando(true);
    setResposta('');

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mensagem })
      });

      const dados = await res.json();
      setResposta(dados.resposta);
    } catch (error) {
      setResposta('Erro ao conectar com a ConsciêncIA.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold mb-4">Bem-vindo à Área do Assinante!</h1>

      <textarea
        placeholder="Digite sua pergunta..."
        value={mensagem}
        onChange={e => setMensagem(e.target.value)}
        className="w-full max-w-xl p-3 rounded mb-4 border border-gray-400"
        rows="4"
      ></textarea>

      <button
        onClick={enviarMensagem}
        className="bg-green-400 text-gray-800 font-bold py-2 px-6 rounded hover:bg-green-600 hover:text-white transition mb-4"
        disabled={carregando}
      >
        {carregando ? 'Enviando...' : 'Enviar'}
      </button>

      {resposta && (
        <div className="bg-white p-4 rounded shadow max-w-xl text-center">
          <strong>Resposta da ConsciêncIA:</strong>
          <p>{resposta}</p>
        </div>
      )}
    </div>
  );
}
}