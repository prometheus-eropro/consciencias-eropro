import { Configuration, OpenAIApi } from 'openai';

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY, // Variável segura
});

const openai = new OpenAIApi(configuration);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { mensagem } = req.body;

  if (!mensagem) {
    return res.status(400).json({ error: 'Mensagem não fornecida.' });
  }

  try {
    const response = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: mensagem }],
    });

    const resposta = response.data.choices[0].message.content;
    return res.status(200).json({ resposta });
  } catch (error) {
    console.error('Erro na API OpenAI:', error.response ? error.response.data : error.message);
    return res.status(500).json({ error: 'Erro ao se conectar à OpenAI.' });
  }
}
