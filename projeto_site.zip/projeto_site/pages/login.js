import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Login() {
  const [emailOuCelular, setEmailOuCelular] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const router = useRouter();

  async function logar() {
    if (!emailOuCelular || !senha) {
      setErro('Preencha todos os campos!');
      return;
    }

    try {
      const resposta = await fetch('/api/validar-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOuCelular, senha })
      });

      const dados = await resposta.json();

      if (dados.acesso) {
        sessionStorage.setItem('emailOuCelular', emailOuCelular);
        router.push('/area-assinante');
      } else {
        setErro('Acesso negado! Verifique seus dados.');
      }
    } catch (error) {
      setErro('Erro ao conectar com o servidor.');
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 p-6 text-white">
      <div className="bg-gray-800 p-8 rounded-xl shadow-lg w-full max-w-sm">
        <h2 className="text-xl font-bold mb-6 text-center">Área de Acesso</h2>

        <input
          type="text"
          placeholder="Email ou celular"
          value={emailOuCelular}
          onChange={e => setEmailOuCelular(e.target.value)}
          className="w-full p-2 mb-4 rounded text-black"
        />

        <input
          type="password"
          placeholder="Senha"
          value={senha}
          onChange={e => setSenha(e.target.value)}
          className="w-full p-2 mb-4 rounded text-black"
        />

        <button
          onClick={logar}
          className="w-full bg-green-400 text-gray-800 font-bold py-2 px-4 rounded hover:bg-green-600 hover:text-white transition"
        >
          Entrar
        </button>

        {erro && <div className="text-red-500 mt-4 text-center">{erro}</div>}
      </div>
    </div>
  );
}
