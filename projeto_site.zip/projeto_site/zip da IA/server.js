const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API ROUTES
app.use('/api/validar-login', require('./api/validar-login'));
app.use('/api/consciencias', require('./api/consciencias'));
app.use('/api/interesse', require('./api/interesse'));
app.use('/api/chat', require('./api/chat'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
